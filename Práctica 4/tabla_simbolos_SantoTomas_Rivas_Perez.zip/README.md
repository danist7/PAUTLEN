PRÁCTICA TABLA DE ŚIMBOLOS
Realizada por:
Daniel SantoTomás López
Lucía Rivas Molina
Luis Pérez Miguel

Para ejecutar:
 - make all
 - ./prueba_tabla <entrada> <mi_salida>

Ejemplos:
  Se incluye el ejemplo dado en el enunciado como ejemplo_enunciado.txt y salida_enunciado.txt
  Además se incluyen tres ejemplos nuestros:
  - ejemplo1 : Con error al intentar abrir un ambito de función cuando estamos dentro del ambito de función
  - ejemplo2 : Con error al realizar un cierre sin haberse abierto ningun ambito local
  - ejemplo3 : Probando la lectura de identificadores definidos fuera y dentro de una función
