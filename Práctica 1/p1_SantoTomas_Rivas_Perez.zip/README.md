#######################################################################
### Práctica 1: Conceptos de Generación de código. El lenguaje NASM ###
#######################################################################

Realizada por:
  - Daniel Santo-Tomás López
  - Lucía Rivas Molina
  - Luis Pérez Miguel

Se puede usar el makefile para la creacion del código NASM y compilarlo para
todos los ejemplos mediante make all.
Se puede ejectuar cada ejemplo con ./ejemplo1ASM cambiando el 1 por cada número
de ejercicio.

También implementado make all, para limpiar cada fichero intermedio
